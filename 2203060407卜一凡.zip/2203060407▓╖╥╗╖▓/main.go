package main

import (
	// "demo/CSV"
	Programs "demo/Program"
)

func main() {
	debt := Programs.NewDebt()
	debt.MainMenu()
}

package CSV

import (
	"encoding/csv"
	"fmt"

	// "fmt"
	"log"
	"os"

	"golang.org/x/text/date"
)

func WriteCSV(C [][]string) {
	//创建csv文件
	f, err := os.OpenFile("Debt.csv", os.O_WRONLY|os.O_TRUNC|os.O_CREATE, 0644)
	if err != nil {
		panic(err)
	}
	//异步管理
	defer f.Close()
	// 写入UTF-8 BOM
	f.WriteString("\xEF\xBB\xBF")
	//创建一个新的写入文件流
	w := csv.NewWriter(f)
	date := [][]string{
	{"1","张三","1000.72","1500.72","500","y"},
	{"2","李四","500","300","-2oo","y"},
	{"3","pig","500","500","0","n"},
	{"4","fzf404","50","30","-20","y"},
}
	//写入数据
	w.WriteAll()
	w.Flush()
}

func ReadCSV() [][]string {
	fileName := "Debt.csv"
	fs1, _ := os.Open(fileName)
	r1 := csv.NewReader(fs1)
	content, err := r1.ReadAll()
	if err != nil {
		log.Fatalf("can not readall, err is %+v", err)
	}

	return content
}

func ShowCSV() {
	fileName := "Debt.csv"
	fs1, _ := os.Open(fileName)
	r1 := csv.NewReader(fs1)
	content, err := r1.ReadAll()
	if err != nil {
		log.Fatalf("can not readall, err is %+v", err)
	}
for i,content := range date {
	fmt.Printf("i=%v content=%v \n",i,content)
}  
}

